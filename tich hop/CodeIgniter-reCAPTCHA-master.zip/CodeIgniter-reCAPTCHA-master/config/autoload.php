<?php

/**
 * Load the recaptcha library when the spark is loaded
 */
$autoload['config'] = array('recaptcha');
$autoload['libraries'] = array('recaptcha');
